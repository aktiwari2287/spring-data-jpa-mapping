package org.nextgen.resource;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.sql.DataSource;

import org.nextgen.dao.DetailTestResultRepository;
import org.nextgen.model.DetailTestResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mysql.jdbc.StringUtils;

@RestController
@RequestMapping("/status")
@CrossOrigin
public class StatusResource {

	@Autowired
	DataSource dataSource;

	@Autowired
	DetailTestResultRepository repository;
	

	@PersistenceContext
	private EntityManager entityManager;

	@PostMapping(consumes = "application/json")
	public List<DetailTestResult> get(@RequestBody Param params) {
		
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<DetailTestResult> query = cb.createQuery(DetailTestResult.class);
		Root<DetailTestResult> detailTestResult = query.from(DetailTestResult.class);
		List<Predicate> predicateLists=new ArrayList();
		if (!StringUtils.isNullOrEmpty(params.getProjectName())) {
			predicateLists.add(cb.equal(detailTestResult.get("projectName"), params.getProjectName()));
		}

		if (!StringUtils.isNullOrEmpty(params.getProductName())) {
			predicateLists.add(cb.equal(detailTestResult.get("productName"),params.getProductName()));
		}

		if (!StringUtils.isNullOrEmpty(params.getProductVersion())) {
			predicateLists.add(cb.equal(detailTestResult.get("productVersion"), params.getProductVersion()));
		}

		if (!StringUtils.isNullOrEmpty(params.getModuleName())) {
			predicateLists.add(cb.equal(detailTestResult.get("moduleName"), params.getModuleName()));
		}

		if (!StringUtils.isNullOrEmpty(params.getExecutionDate())) {
			predicateLists.add(cb.equal(detailTestResult.get("executionDate"), params.getExecutionDate()));
		}
		if (!StringUtils.isNullOrEmpty(params.getStatus())) {
			predicateLists.add(cb.equal(detailTestResult.get("status"), params.getStatus()));
		}
		if (!StringUtils.isNullOrEmpty(params.getTestcaseId())) {
			predicateLists.add(cb.equal(detailTestResult.get("testcaseId"), params.getTestcaseId()));
		}
		query.select(detailTestResult).where(cb.and(predicateLists.toArray(new Predicate[0])));

		return entityManager.createQuery(query).getResultList();

	}

	private List<DetailTestResult> findDetailTestResultByEmails() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<DetailTestResult> query = cb.createQuery(DetailTestResult.class);
		Root<DetailTestResult> detailTestResult = query.from(DetailTestResult.class);
		query.select(detailTestResult).where(cb.and(cb.equal(detailTestResult.get("projectName"), "NGO")));
		return entityManager.createQuery(query).getResultList();
	}
	
	@GetMapping("/dropdown")
	public Map<String,List<Object>> getDropdownValues(){
		Map<String,List<Object>> dropdown=new LinkedHashMap<>();
		dropdown.put("projectName",repository.getDistinctProjectName());
		dropdown.put("productName",repository.getDistinctProductName());
		dropdown.put("productVersion",repository.getDistinctProductVersion());
		dropdown.put("moduleName",repository.getDistinctModuleName());
		dropdown.put("status",repository.getDistinctStatus());
		//dropdown.put("testcaseId",repository.getDistinctTestcaseId());
		return dropdown;
	}

}
