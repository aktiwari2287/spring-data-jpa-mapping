package org.nextgen.resource;

public class Param {
	
	private String projectName;
	private String productName;
	private String productVersion;
	private String moduleName;
	private String executionDate;
	private String testcaseId;
	public Param() {
	}
	public Param(String projectName, String productName, String productVersion, String moduleName, String executionDate,
			String status,String testcaseId) {
		super();
		this.projectName = projectName;
		this.productName = productName;
		this.productVersion = productVersion;
		this.moduleName = moduleName;
		this.executionDate = executionDate;
		this.status = status;
		this.testcaseId=testcaseId;
	}
	public String getTestcaseId() {
		return testcaseId;
	}
	public void setTestcaseId(String testcaseId) {
		this.testcaseId = testcaseId;
	}
	private String status;
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductVersion() {
		return productVersion;
	}
	public void setProductVersion(String productVersion) {
		this.productVersion = productVersion;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getExecutionDate() {
		return executionDate;
	}
	public void setExecutionDate(String executionDate) {
		this.executionDate = executionDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
