package org.nextgen.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "DETAIL_TEST_RESULT")
public class DetailTestResult {
	@Id
	@SequenceGenerator(name="seq", sequenceName="DETAIL_TEST_RESULT_SEQ")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq")
	@Column(name="ID")
	private int id;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "TEST_CASE_ID")
	private int testCaseID;

	@Column(name = "HOST_NAME")
	private String hostName;

	@Column(name = "PROJECT_NAME")
	private String projectName;

	@Column(name = "PRODUCT_NAME")
	private String productName;

	@Column(name = "PRODUCT_VERSION")
	private String productVersion;

	@Column(name = "MODULE_NAME")
	private String moduleName;

	@Column(name = "TC_NAME")
	private String tcName;

	@Column(name = "USER_ACTION")
	private String userAction;

	@Column(name = "EXECUTION_TIME")
	private String executionTime;

	@Column(name = "EXECUTION_DATE")
	private String executionDate;

	@Column(name = "EXPECTED_RESULT")
	private String expectedResult;

	@Column(name = "ACTUAL_RESULT")
	private String actualResult;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "FAILURE_SCREENSHOT_PATH")
	private String failureScreenshotsPath;

	@Column(name = "TEST_SCRIPT_PATH")
	private String testScriptPath;

	@Column(name = "TEST_DATA_PATH")
	private String testDataPath;

	@Column(name = "REPORT_PATH")
	private String reportPath;

	public int getTestCaseID() {
		return testCaseID;
	}

	public void setTestCaseID(int testCaseID) {
		this.testCaseID = testCaseID;
	}

	public String getHostName() {
		return hostName;
	}

	public void setHostName(String hostName) {
		this.hostName = hostName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductVersion() {
		return productVersion;
	}

	public void setProductVersion(String productVersion) {
		this.productVersion = productVersion;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getTcName() {
		return tcName;
	}

	public void setTcName(String tcName) {
		this.tcName = tcName;
	}

	public String getUserAction() {
		return userAction;
	}

	public void setUserAction(String userAction) {
		this.userAction = userAction;
	}

	public String getExecutionTime() {
		return executionTime;
	}

	public void setExecutionTime(String executionTime) {
		this.executionTime = executionTime;
	}

	public String getExecutionDate() {
		return executionDate;
	}

	public void setExecutionDate(String executionDate) {
		this.executionDate = executionDate;
	}

	public String getExpectedResult() {
		return expectedResult;
	}

	public void setExpectedResult(String expectedResult) {
		this.expectedResult = expectedResult;
	}

	public String getActualResult() {
		return actualResult;
	}

	public void setActualResult(String actualResult) {
		this.actualResult = actualResult;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFailureScreenshotsPath() {
		return failureScreenshotsPath;
	}

	public void setFailureScreenshotsPath(String failureScreenshotsPath) {
		this.failureScreenshotsPath = failureScreenshotsPath;
	}

	public String getTestScriptPath() {
		return testScriptPath;
	}

	public void setTestScriptPath(String testScriptPath) {
		this.testScriptPath = testScriptPath;
	}

	public String getTestDataPath() {
		return testDataPath;
	}

	public void setTestDataPath(String testDataPath) {
		this.testDataPath = testDataPath;
	}

	public String getReportPath() {
		return reportPath;
	}

	public void setReportPath(String reportPath) {
		this.reportPath = reportPath;
	}
}
