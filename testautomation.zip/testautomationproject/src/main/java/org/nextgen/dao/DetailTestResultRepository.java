package org.nextgen.dao;

import java.util.List;

import org.nextgen.model.DetailTestResult;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface DetailTestResultRepository extends CrudRepository<DetailTestResult, Long> {
	
	@Query("select DISTINCT(d.projectName) from DetailTestResult d")
	List<Object> getDistinctProjectName();
	
	@Query("select DISTINCT(d.productName) from DetailTestResult d")
	List<Object> getDistinctProductName();
	
	@Query("select DISTINCT(d.productVersion) from DetailTestResult d")
	List<Object> getDistinctProductVersion();

	@Query("select DISTINCT(d.moduleName) from DetailTestResult d")
	List<Object> getDistinctModuleName();

	@Query("select DISTINCT(d.status) from DetailTestResult d")
	List<Object> getDistinctStatus();
	
	@Query("select DISTINCT(d.testCaseID) from DetailTestResult d")
	List<Object> getDistinctTestcaseId();
	
}
