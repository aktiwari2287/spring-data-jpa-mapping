package com.anand;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibManagmentApplication.class, args);
	}

}
